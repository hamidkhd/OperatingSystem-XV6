#include "types.h"
#include "user.h"
#include "fcntl.h"

int main(void){
	//printf(1,"hi\n");
	
	printf(1, "salam\n");

	int a = 4;
	while(1){
		
		a++;
	
	}

	exit();
}